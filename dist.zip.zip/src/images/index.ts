import twitter_logo_dark from "./twitter-logo-dark.png"
import logo_dark from "./logo-dark.png"

export {
    logo_dark, twitter_logo_dark
};